"""Module requiring Paste to test dependencies download of pip wheel."""

__version__ = '3.1.4'
